package com.pack;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.pack.model.Book;



public class BookMain {

	public static void main(String[] args) {
	StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("Hibernate.config.xml").build();
	Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
	org.hibernate.SessionFactory factory=meta.getSessionFactoryBuilder().build();
	Session session=factory.openSession();
	Transaction tr=session.getTransaction();
	Book bobj1=new Book();
	bobj1.setId(1);
	bobj1.setTitle("Geetanjali");
	bobj1.setAuthor("Ravindra Nath Tagore");
	session.save(bobj1);
	try {
	    // create session
	    tr = session.beginTransaction();
		System.out.println("Books saved successfully");
	    tr.commit();
	} catch (Exception exp) {
	    tr.rollback();
	    // close session
	}	
	factory.close();
	session.close();
	}

}
